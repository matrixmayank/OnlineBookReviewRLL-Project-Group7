import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ufooter',
  templateUrl: './ufooter.component.html',
  styleUrls: ['./ufooter.component.css']
})
export class UfooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
